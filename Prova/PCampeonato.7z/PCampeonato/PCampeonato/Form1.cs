﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            int[,] MatrizTimes = new int[7, 3];
            int golsFeitos1 = 0, golsRecebidos1 = 0, golsFeitos2 = 0, golsRecebidos2 = 0, saldoGols = 0,  saldoGols1 = 0, piorTime=0;
            string auxGolsFeitos = "", auxGolsRecebidos = "";
            for (int t = 0; t < 7; t++)//times
            {
                for (int gf = 0; gf < 1; gf++)//gols feitos
                {
                    auxGolsFeitos = Interaction.InputBox("Digite os gols feitos do Time " + (t + 1) + ": ");

                    if (int.TryParse(auxGolsFeitos, out MatrizTimes[t, gf]))//validando int
                    {
                        if (MatrizTimes[t, gf] < 0)
                        {
                            MessageBox.Show("Valor de gols inválido.");
                            gf--;
                        }
                        else
                        {
                            golsFeitos1 = MatrizTimes[t, gf];
                        }
                    }
                    else
                        MessageBox.Show("Valores Inválidos.");
                }

                for (int gr = 1; gr < 2; gr++)//gols recebidos
                {
                    auxGolsRecebidos = Interaction.InputBox("Digite os gols recebidos do Time " + (t + 1) + ": ");

                    if (int.TryParse(auxGolsRecebidos, out MatrizTimes[t, gr]))//validando int
                    {
                        if (MatrizTimes[t, gr] < 0)
                        {
                            MessageBox.Show("Valor de gols inválido.");
                            gr--;
                        }
                        else
                        {
                            golsRecebidos1 = MatrizTimes[t, gr];
                        }

                    }
                    else
                        MessageBox.Show("Valores Inválidos.");
                }

                for (int gs = 2; gs < 3; gs++)//saldo de gols
                {
                    saldoGols = golsFeitos1 - golsRecebidos1;

                }

                lstBoxTimes.Items.Add("Time: " + (t + 1) + ". Gols feitos: " + golsFeitos1 + ". Gols recebidos: " + golsRecebidos1 + " Saldo de gols: " + saldoGols + ".");
            }

        }
    }
}